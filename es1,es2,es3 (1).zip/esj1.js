const products = [
    { id: 1, name: 'T-Shirt', price: 150.00, image: 'tshirt.jpeg', category: 'clothing' },
    { id: 2, name: 'Running Shoes', price: 650.50, image: 'runningshoes.jpeg', category: 'sports' },
    { id: 3, name: 'Cricket-Bat', price: 7000.00, image: 'bat.jpeg', category: 'sports' },
    { id: 4, name: 'Masterpieces', price: 420.50, image: 'novel1.jpeg', category: 'books' },
    { id: 5, name: 'Mens-Jeans', price: 799.00, image: 'jeans.jpeg', category: 'clothing' },
    { id: 6, name: 'Leather-ball', price: 550.50, image: 'lball.jpeg', category: 'sports' },
    { id: 7, name: 'Badminton-Racket', price: 150.00, image: 'racket.jpeg', category: 'sports' },
    { id: 8, name: 'Womens-Jeans', price: 799.00, image: 'wjeans.jpeg', category: 'clothing' },
    { id: 9, name: 'Top', price: 500.00, image: 'top.jpeg', category: 'clothing' },
    { id: 10, name: 'Solar Bones', price: 389.50, image: 'novel2.jpeg', category: 'books' },
    { id: 11, name: 'AB-Autobiography', price: 389.50, image: 'novel3.jpeg', category: 'books' },
    { id: 12, name: 'Nature-Book', price: 320.50, image: 'novel4.jpeg', category: 'books' },
    { id: 13, name: 'Batting-Gloves', price: 650.00, image: 'gloves.jpeg', category: 'sports' },
    { id: 14, name: 'Badminton-cock', price: 500.00, image: 'cock.jpeg', category: 'sports' },
    { id: 15, name: 'Mens-watch', price: 850.00, image: 'mwatch.jpeg', category: 'clothing' },
    { id: 16, name: 'Womens-watch', price: 900.50, image: 'wwatch.jpeg', category: 'clothing' },
    { id: 17, name: 'Smart-watch', price: 1150.00, image: 'swatch.jpeg', category: 'clothing' }
];

let cart = JSON.parse(localStorage.getItem('cart')) || [];

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function displayProducts(filteredProducts = products) {
    const productContainer = document.getElementById('product-list');
    productContainer.innerHTML = ''; 

    filteredProducts.forEach(product => {
        const productElement = `
            <div class="product" style="
                flex: 1 1 calc(25% - 20px); 
                border: 1px solid #ddd; 
                padding: 10px; 
                box-sizing: border-box;
                display: inline-block;
                vertical-align: top;
            ">
                <img src="${product.image}" alt="${product.name}" style="width: 100%; height: auto;">
                <h3>${product.name}</h3>
                <p>$${product.price.toFixed(2)}</p>
                <button onclick="addToCart(${product.id})" style="
                    background-color: #28a745; 
                    color: white; 
                    border: none; 
                    padding: 10px; 
                    cursor: pointer; 
                    width: 100%; 
                    box-sizing: border-box;
                ">Add to Cart</button>
            </div>
        `;
        productContainer.innerHTML += productElement;
    });
}


function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    saveCart();
    alert(`${product.name} has been added to your cart!`);
}

function displayCartItems() {
    const cartItemsContainer = document.getElementById('cart-items');
    let cartTotal = 0;
    cartItemsContainer.innerHTML = ''; 
    cart.forEach(item => {
        const cartItem = `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <p>$${item.price.toFixed(2)}</p>
                </div>
                <div class="item-price">
                    <p>$${item.price.toFixed(2)}</p>
                </div>
            </div>
        `;
        cartItemsContainer.innerHTML += cartItem;
        cartTotal += item.price;
    });
    document.getElementById('cart-total').textContent = cartTotal.toFixed(2);
}

function displayBillingDetails() {
    const billingDetailsContainer = document.getElementById('billing-details');
    let billingDetails = '<h2>Your Purchase Summary:</h2>';
    let totalAmount = 0;

    cart.forEach(item => {
        billingDetails += `
            <div>
                <h3>${item.name}</h3>
                <p>Price: $${item.price.toFixed(2)}</p>
            </div>
        `;
        totalAmount += item.price;
    });

    billingDetails += `<h3>Total: $${totalAmount.toFixed(2)}</h3>`;

    const address = localStorage.getItem('address');
    const paymentMethod = localStorage.getItem('paymentMethod');

    billingDetails += `
        <p><strong>Shipping to:</strong> ${address}</p>
        <p><strong>Payment Method:</strong> ${paymentMethod}</p>
    `;

    billingDetailsContainer.innerHTML = billingDetails;
}

function saveCheckoutDetails(address, paymentMethod) {
    localStorage.setItem('address', address);
    localStorage.setItem('paymentMethod', paymentMethod);
}

function authenticate(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username.length >= 5 && /\d/.test(password)) {
        alert('Login successful!');
        window.location.href = 'es2.html';
    } else {
        alert('Username must be at least 5 characters and password must contain at least one number.');
    }
}

document.getElementById('checkout-form')?.addEventListener('submit', function(event) {
    event.preventDefault();
    const address = document.getElementById('address').value;
    const paymentMethod = document.getElementById('payment-method').value;
    saveCheckoutDetails(address, paymentMethod);
    window.location.href = 'es5.html';
});

document.getElementById('auth-form')?.addEventListener('submit', authenticate);

document.getElementById('category-filter')?.addEventListener('change', function() {
    const selectedCategory = this.value;
    const filteredProducts = selectedCategory === 'all'
        ? products
        : products.filter(product => product.category === selectedCategory);
    displayProducts(filteredProducts);
});

function logout() {
    localStorage.removeItem('cart'); 
    localStorage.removeItem('address'); 
    localStorage.removeItem('paymentMethod'); 
    alert('You have been logged out.');
    window.location.href = 'es1.html'; 
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('product-list')) {
        displayProducts(); 
    }

    if (document.getElementById('cart-items')) {
        displayCartItems(); 
    }

    if (document.getElementById('billing-details')) {
        displayBillingDetails(); 
    }
});
